---
name: google-docs-builder
description: Create properly formatted native Google Docs in the user's Google Drive, either from scratch in a clean house style or by cloning an existing Google Doc's full formatting (header, footer, logo, cover page, fonts, numbered headings, table styles) and filling it with new content. Use this whenever the user wants a Google Doc as the result ("crea un Google Doc", "ponlo en Drive", "hazlo en Docs"), shares a docs.google.com link and asks for a new document based on it ("usa esta plantilla", "con el mismo formato que este", "clone this doc's formatting"), or asks for a uCloud client proposal, SOW, PoC proposal or professional-services quote, even if they never say "Google Docs". Not for .docx/PDF files the user explicitly wants to download, and not for editing the text of an existing Doc in place.
---

# Google Docs builder

Produces a **new native Google Doc** in the user's Drive. The Google Drive
connector can create files (converting .docx or HTML into Google Docs) but
cannot edit an existing Doc's text, so "update this Doc" means "make a new
version of it". Say so if the user seems to expect an in-place edit.

## Pick the route first

| Situation | Route | User effort |
|---|---|---|
| Clone a template / existing Doc (any real header, logo, cover) | **A. Clone & fill** → .docx → uploader page | one click |
| No template, content-focused doc (memo, notes, plan, report) | **B. Direct HTML** → `create_file` | none |
| No template but needs header/footer/logo/page numbers | **C. Build .docx** → uploader page | one click |

Why two delivery paths: a tool call can carry a few dozen KB of text reliably,
not a 300 KB binary. HTML you write fits in the call (route B). A .docx lives
in the workspace, so it goes into a small private page that uploads it with the
user's own Drive connection (routes A and C). Never try to paste a .docx's
base64 into `create_file` yourself; it will be truncated or corrupted.

Load Drive tools with `tool_search("Google Drive create file")` if they
aren't loaded yet.

## Route A: clone & fill a template

1. **Find the template.** Link → file id (the part after `/d/`). Name →
   `search_files`. Known templates are documented in
   `references/templates/` (check it first; e.g. uCloud proposals/SOWs use
   `ucloud-proposal.md`, no link needed). If the request is a uCloud proposal,
   read that file now.
2. **Export it as .docx**: `download_file_content(fileId, exportMimeType=
   "application/vnd.openxmlformats-officedocument.wordprocessingml.document")`.
   The result is saved to a JSON file whose path the tool returns. Decode it
   without reading it into context:
   ```bash
   S=<skill-dir>/scripts; mkdir -p /home/claude/work && cd /home/claude/work
   python3 $S/extract_export.py <tool_result.json> template.docx
   python3 $S/slim_docx.py template.docx template-slim.docx   # drops embedded fonts Docs already has
   python3 $S/docx_template.py inspect template-slim.docx
   ```
3. **Understand the template from `inspect`.** It tags every paragraph:
   `PLACEHOLDER` (`[Nombre del cliente]`), `GUIDANCE` (fully highlighted text
   = instructions for the author, to follow and then remove), `LITERAL`
   (`<LITERAL>…<LITERAL>` = keep verbatim), plain text (boilerplate, keep),
   and lists each table's rows. Unknown template without those conventions?
   Treat example-looking body text as guidance to replace and keep anything
   that reads like standard terms; when unsure, ask one question.
4. **Gather the content.** From the conversation, pasted notes, attached
   files, Drive docs, email or other connectors the user points to. Pull the
   facts yourself rather than asking the user to retype them. Missing
   commercial numbers (rates, hours, discounts): use what the user gave; if you
   must estimate, list every estimate in your final reply.
5. **Write a spec** (`references/spec-format.md` has every key): cover
   `replace`, `sections` for each guidance block, `tables` for every example
   table, `keep` blocks for LITERALs you rewrite around, and the template's
   profile JSON if one exists. If the user wants a *different kind* of
   document in the template's look (a report in the proposal's styling), use
   `rebuild_body` with `heading`, text, bullet and `table` blocks instead of
   filling the old sections. Write real, specific content: the template's
   guidance says what each section needs, and a reader should never see
   generic filler or the template's examples.
6. **Fill and fix warnings:**
   ```bash
   python3 $S/docx_template.py fill template-slim.docx spec.json out.docx
   ```
   Warnings are a to-do list (placeholders left, guidance you didn't cover,
   example values still present). Update the spec and re-run until `OK`.
7. **Look at it.** Render and check the cover and a few content pages:
   ```bash
   python /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf out.docx
   pdftoppm -jpeg -r 60 -f 1 -l 4 out.pdf pg   # then view pg-1.jpg … (more pages if tables changed)
   ```
   LibreOffice is only a preview; Google's conversion is faithful to the XML.
8. **Deliver** with the uploader page (see "Delivering a .docx").

## Route B: direct HTML (no template)

Read `references/house-style.md`, write the document as HTML with inline CSS,
and call `create_file` with `title`, `textContent=<html>`,
`contentMimeType="text/html"` (and `parentId` if the user named a folder).
Return the `viewUrl`. Keep the HTML under ~150 KB; beyond that, use route C.

## Route C: new .docx with header/logo

Read `/mnt/skills/public/docx/SKILL.md` and build the file with docx-js
following the house-style look (Google Sans, dark text, one blue accent).
Then `slim_docx.py` and deliver with the uploader page.

## Delivering a .docx (routes A and C)

```bash
python3 $S/make_uploader.py out.docx /mnt/user-data/outputs/<slug>.html \
  --title "<final Google Doc title>" --summary "<one line>" --lang es \
  [--parent <folderId> --parent-name "<folder name>"]
```
Publish with the Artifact tool:
`file_path` = that HTML, `favicon` "📄", and
`capabilities` = `{"mcp": {"servers": [{"server": "Google Drive", "tools": ["create_file"]}]}, "downloads": true}`.
The user clicks **Crear en Google Drive** (first time: a consent prompt) and
gets the link. The same page offers "Descargar .docx" as a fallback. Don't also
call `present_files` for the .docx unless the user asks for the file.

Title: follow the template's naming pattern if it has one (uCloud:
`uCloud - YYYYMMDD - Propuesta - <Cliente> - <Solución>`), otherwise a plain
descriptive title.

## Language

Write in the language of the request and template. For uCloud this means
Spanish for internal and client documents, English for anything addressed to
Google (escalations, billing cases).

## Final reply

Short: what was created (the publish card or Doc link does the rest), then only
what the user must act on: values you estimated or couldn't fill, anything you
deliberately left out, and, for route A, "refresh the table of contents in
Docs (click it → ⟳) to get page numbers". No recap of every section.
