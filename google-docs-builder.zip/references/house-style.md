# House style for documents without a template (route: direct HTML)

Used when the user wants a Google Doc but gave no template to clone. You write
the HTML yourself and pass it as `textContent` with
`contentMimeType: "text/html"` to Google Drive `create_file`; Drive converts it
into a native Google Doc in one call, no click needed.

## What survives Drive's HTML import (verified)

Headings `h1`–`h3` (become real Google Docs headings, so the outline works),
`font-family`, `color`, `font-size`, bold/italic/underline, links, `ul`/`ol`
(nested too), tables with `border`, `background` and `padding` on cells,
`page-break-before: always`.

Not available this way: headers/footers, page numbers, a real TOC field,
embedded images (only small `data:` URIs, avoid), custom margins. If the user
needs those, build a .docx instead (see "No template but needs a header or
logo" in SKILL.md).

## Skeleton

Keep all CSS inline: Drive ignores `<style>` blocks for most properties.

```html
<html><body style="font-family:'Google Sans',Arial,sans-serif;font-size:11pt;color:#202124;line-height:1.4">
<p style="font-size:10pt;color:#5f6368;margin:0">uCloud Global · 29/09/2026</p>
<h1 style="font-size:24pt;color:#1a73e8;margin:6pt 0 12pt">Título del documento</h1>
<p>Párrafo de introducción con una idea clara por frase.</p>
<h2 style="font-size:16pt;color:#202124;margin:18pt 0 6pt">1. Sección</h2>
<p>Texto…</p>
<ul><li>Punto con <b>término clave</b> y explicación.</li></ul>
<table style="border-collapse:collapse;width:100%">
 <tr><th style="border:1px solid #dadce0;background:#e8f0fe;padding:6pt;text-align:left">Columna</th>
     <th style="border:1px solid #dadce0;background:#e8f0fe;padding:6pt;text-align:left">Columna</th></tr>
 <tr><td style="border:1px solid #dadce0;padding:6pt">Valor</td>
     <td style="border:1px solid #dadce0;padding:6pt">Valor</td></tr>
</table>
</body></html>
```

## Style rules

- Google Sans (falls back to Arial), 11 pt body, dark grey `#202124`.
- One blue accent `#1a73e8` for the title only; section headings stay dark.
- Number sections in the heading text ("1. Contexto", "1.1 Alcance") for
  formal documents; skip numbering for short internal notes.
- Tables: light grey borders `#dadce0`, header row `#e8f0fe`, left-aligned
  text, numbers right-aligned (`text-align:right`).
- Use real lists, never "•" characters or hyphens typed into paragraphs.
- Put a small metadata line above the title (organization · date · author)
  for formal docs.
- Payload limit: keep the HTML under ~150 KB; for anything bigger, build a
  .docx and use the uploader page.
