# Fill spec format (`docx_template.py fill`)

A spec is one JSON object. Every key is optional. The engine applies them in
this order, so structural changes see the template's original wording:

`profiles` → `promote` → `delete_paragraphs` → `rebuild_body` → `delete_sections` →
`remove_images` / `replace_image` → `tables` → `sections` → `set_paragraphs`
→ `replace` → `fixes` → finalize

Section and table lookups use the **heading text** as shown by `inspect`
(case- and punctuation-insensitive; a unique substring also works).

## Keys

```jsonc
{
  // Template profiles to merge in (fixes, promotions, deletions, must_change).
  "profiles": ["<skill>/references/templates/ucloud-proposal.json"],

  // Exact text swaps anywhere (body, tables, header/footer). Formatting of the
  // original run is kept. Use for cover placeholders and one-off values.
  "replace": {
    "[Nombre del cliente]": "Grupo Calleja",
    "Total ACV: $123,456.00": "Total ACV: $84,200.00"
  },

  // Replace the whole text of the first paragraph matching a regex, keeping
  // its paragraph style. Good for sentences that are wrong as a whole.
  "set_paragraphs": [
    {"match": "^Este SOW tiene una fecha", "text": "La fecha de entrada en vigor de esta Declaración de Trabajo es el **13/10/2026** y la fecha estimada de entrega es el **04/12/2026**."}
  ],

  // Rewrite section bodies. Key = heading text. Value = list of blocks, or
  // {"mode": ..., "content": [...]}.
  //   mode "guidance" (default): delete the highlighted guidance paragraphs in
  //       that section and put the blocks where the first one was; keep
  //       everything else (boilerplate, LITERALs, tables).
  //   mode "replace_all": delete every paragraph (not tables) in the section.
  //   mode "append": add after the section's last element.
  // A section runs from its heading to the next heading of ANY level, so a
  // Heading 1 with Heading 2 children is filled child by child.
  "sections": {
    "Resumen Ejecutivo": [
      "Grupo Calleja opera **más de 100 tiendas** ...",
      {"type": "bullet", "text": "Reducir el tiempo de cierre contable de 5 a 2 días."}
    ],
    "Supuestos y Consideraciones": {"content": [
      {"type": "bullet", "text": "**Supuestos:**", "level": 0},
      {"type": "bullet", "text": "El cliente proveerá accesos de administrador a su organización GCP.", "level": 1},
      {"type": "keep", "match": "conexión estable de internet"},
      {"type": "keep", "match": "Tras la firma del contrato"},
      {"type": "bullet", "text": "**Consideraciones:**", "level": 0},
      {"type": "keep", "match": "máxima calidad y especialización"}
    ]}
  },

  // Refill a table in place: keeps header row(s), clones the first body row's
  // formatting for every new row, optionally rewrites the last (footer) row.
  "tables": [
    {"section": "Actividades", "nth": 0,
     "rows": [["Planeación", "Kick-off y refinamiento de requerimientos", "Cliente / uCloud", "6"],
              ["", "Diseño de landing zone", "uCloud", "12"]],
     "footer": ["**Total de horas**", "**18**"]},          // omit "footer" if the table has no totals row; null deletes it
    {"section": "Matriz de Responsabilidades (RACI)",
     "header": ["RACI", "uCloud", "Grupo Calleja"],         // rewrite header cells (count must match the header row's cells)
     "rows": [["1- Creación de la organización GCP.", "R", "A", "C", "I"]]},
    {"section": "Línea de tiempo",
     "widths_pct": [28, 9, 9, 9, 9, 9, 9, 9, 9],           // optional: redistribute column widths
     "rows": [["**Implementación**", {"text": "", "fill": null}, {"text": "", "fill": "FCE5CD"}]]}  // cell shading on/off
  ],

  // Different kind of document, same look: keep cover, TOC, header/footer,
  // styles and page setup; replace everything from the first numbered
  // Heading 1 (or "from": "<heading>") to the end with new blocks.
  "rebuild_body": {"content": [
    {"type": "heading", "text": "Resumen del proyecto", "level": 1},
    "Texto…",
    {"type": "table", "like": "Actividades", "header": ["Hito", "Actividad", "Responsable", "Horas"],
     "rows": [["Planeación", "Kick-off", "uCloud", "4"]], "footer": ["**Total**", "**4**"]}
  ]},

  // Remove a section with everything under it (incl. sub-headings).
  "delete_sections": ["Rampa de Consumo"],

  // Remove paragraphs by regex. "occurrence": n removes only the n-th match.
  "delete_paragraphs": [{"match": "^Calculadora:", "occurrence": 1}],

  // Turn a plain paragraph into a real heading copied from an existing one
  // (style + auto-numbering).
  "promote": [{"match": "^15\\. Firmas", "text": "Firmas", "like": "Precios de Servicios Profesionales"}],

  // Images: drop the example image(s) in a section, or swap the first image
  // for a file (aspect ratio adjusted, width kept).
  "remove_images": ["Diagrama de Arquitectura"],
  "replace_image": [{"section": "Diagrama de Arquitectura", "path": "/home/claude/work/arch.png"}],

  // Regex fixes on every paragraph ({"find", "replace"}, Python syntax, \\1 groups).
  "fixes": [],

  // Regexes that must NOT appear in the final document (example values).
  "must_change": []
}
```

## Blocks (for `sections`)

| block | result |
|---|---|
| `"text"` or `{"type":"p","text":...}` | body paragraph (template's body style) |
| `{"type":"bullet","text":...,"level":0\|1}` | bullet copied from the template's own list |
| `{"type":"heading","text":...,"level":2}` | heading copied from the template (keeps numbering) |
| `{"type":"label","text":"Prerrequisitos:"}` | bold lead-in line |
| `{"type":"keep","match":"regex"}` | move an existing paragraph here untouched (use for `<LITERAL>` items) |
| `{"type":"table","like":"<section>","nth":0,"header":[...],"rows":[[...]],"footer":[...]}` | new table copying the design of a template table (same column count; header row, first body row and last row are the prototypes). Pick a source whose column alignment fits your data: e.g. a table with a right-aligned numeric last column suits amounts, not text |

Inline markup inside any text: `**bold**`, `*italic*`, `[text](https://url)`.
Table cells take the same markup; a cell value that is a list becomes one
paragraph per item, copying the cell's first paragraph (so a bulleted cell
stays bulleted). `null` leaves a cell untouched. A cell value can also be an object
`{"text": ..., "fill": "RRGGBB" | null}` to set or clear its shading (for
Gantt-style grids, status colors). Rows cloned from the template copy the
example row's shading, so set `fill` explicitly on every cell of a grid.

## Finalize (always runs)

- `<LITERAL>` markers stripped, text kept verbatim, highlight removed.
- Any remaining all-highlighted guidance paragraph is deleted **and listed as
  a warning**. That list tells you which author instructions you didn't
  address, so read it.
- Empty bullets left behind are removed.
- Table of contents rebuilt from the final headings (numbered, linked, no
  page numbers; Google Docs fills them in on refresh).
- Warnings for: leftover `[placeholders]`, remaining highlight, `must_change`
  hits, `replace` strings that weren't found.

Treat warnings as a to-do list: fix the spec and re-run until the output says
`OK`, or consciously accept a warning and tell the user why.
