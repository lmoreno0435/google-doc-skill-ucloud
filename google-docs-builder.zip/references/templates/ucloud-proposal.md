# uCloud proposal / SOW template ("Modelo Propuesta v2")

- **Drive file:** `1Pd4MAxIcxXVGG7JA5nJvAE4PAsOTxxWfNdhGyrC7JGY`
  (title "uCloud - 20250107 - Modelo Propuesta v2_ Base Prompt v5")
- **Use for:** client proposals, SOWs, PoC proposals, "propuesta", "cotización
  de servicios profesionales", "statement of work" for uCloud.
- **Language:** Spanish. Keep it Spanish even if the request was typed in English,
  unless the user explicitly asks for an English proposal.
- **Profile:** always include
  `"profiles": ["<skill>/references/templates/ucloud-proposal.json"]` in the spec.
  It fixes the template's known defects (iCloud/Cloud global → uCloud Global,
  hand-numbered sections 12–15 → real numbered headings, stray TOC entries,
  duplicated consent line, "misa"/"para para" typos, English timeline headers)
  and flags example values that must never ship.

## What each part of the template means

| Marker | Meaning | What to do |
|---|---|---|
| `[Bracketed]` on the cover | field | `replace` with real value |
| yellow-highlighted text | instruction to the presales author | follow it, write the real content (via `sections`), let finalize delete it |
| `<LITERAL> … <LITERAL>` | mandatory legal/commercial text | keep verbatim (use `keep` blocks if you rewrite around it) |
| unhighlighted text | boilerplate | keep, except the example values below |
| example tables | show the shape only | refill every row via `tables`; recompute totals |

## Section-by-section

- **Cover:** `[Nombre del cliente]`, `[Tipo de Propuesta (Proyecto o PoC)]` →
  "Propuesta de Proyecto" or "Propuesta de PoC", `[Nombre de la solución]`,
  `[Fecha (formato dd/mm/yyyy)]` → today in dd/mm/yyyy, `[Autor]` → the user's
  name unless told otherwise, `[Logo del Cliente]` → the client's name in plain
  text (tell the user they can paste the logo there in Google Docs).
- **Resumen Ejecutivo:** who the client is, what motivates the project,
  high-level objectives, who uCloud is and relevant experience (Google Premier
  Partner, Workspace + GCP, offices in Spain and LATAM). Then replace the
  broken date sentence with `set_paragraphs` on `^Este SOW tiene una fecha`.
- **Requerimientos Funcionales / No Funcionales:** concrete bullets ("what" vs
  "how"). Never keep the template's ML/chatbot examples.
- **Criterios de Éxito:** measurable, agreed-with-client objectives.
- **Actividades:** table Hito | Actividad | Responsable | Horas. Leave the Hito
  cell empty for continuation rows. Footer = total hours (must equal the sum).
- **Entregables:** one row per hito; cell can be a list of `**Name:** description`.
- **Línea de tiempo:** start date = proposal date + 14 days (next Monday is
  fine); end date from the weeks needed. Assume ~30% weekly dedication of the
  operations engineer when estimating weeks. Refill the week grid with one row
  per phase: shade active weeks with `{"text": "", "fill": "FCE5CD"}` and clear
  the rest with `{"text": "", "fill": null}` (the example row's shading is
  otherwise copied to every row). Add `"widths_pct": [28, 9, 9, 9, 9, 9, 9, 9, 9]`
  so phase names don't break mid-word. The grid has 8 week columns; leave
  unused ones empty, and for longer projects group weeks (e.g. "Sem. 1-2").
- **Diagrama de Arquitectura:** if no diagram is provided, remove the example
  image (`remove_images`) and add one paragraph describing the architecture
  plus a note that the diagram will be attached. Never ship the example image.
- **Calculadora de Precios GCP:** replace "Total ACV: $123,456.00" with the real
  figure, or "Por definir" if unknown (and tell the user).
- **Rampa de Consumo:** refill; delete the section for PoCs.
- **Responsabilidades:** prerequisites are boilerplate. Refill uCloud roles,
  client roles (include the executive sponsor / POE approver), RACI (header =
  "RACI" + uCloud + client name; rows = real activities).
- **Elementos fuera de alcance:** specific exclusions; generic clauses are
  explicitly discouraged by the template.
- **Supuestos y Consideraciones:** two groups ("Supuestos:", "Consideraciones:")
  each with project-specific bullets **plus** the LITERAL items kept via `keep`.
- **Desglose de costos:** Categoría | FTE | Num. Hours | Costo x Hora |
  Descuento % | Total, footer with totals. The 16% PSF/DAF margin note applies
  only to Mexico proposals. Fill "(Valor Total, servicios)" with the total.
- **Beneficios de uCloud:** "USD 7.214" is an example amount: replace it or
  remove the paragraph if there is no implementation discount.
- **Firmas table:** client column needs the client signer's name/role; dates
  become the real month ("Octubre de 2026"). uCloud signer (Blanca Serra, CEO)
  is template data: keep unless told otherwise.
- **Anexos:** list annexes or write "No aplica".

Number format: the template mixes `$4.300` and `$123,456.00`. Use the
Latin-American style used in the tables (`$4.300`, thousands with a dot) unless
the user's data uses another convention; be consistent across the document.

If information is missing (rates, hours, names), don't invent commercial
numbers silently: use the user's data, or reasonable estimates that you
clearly list as assumptions in your reply so presales can adjust them.
