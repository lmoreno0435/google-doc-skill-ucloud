#!/usr/bin/env python3
"""Clone-and-fill engine for .docx templates exported from Google Docs.

Two commands:

  docx_template.py inspect template.docx
      Prints an outline: every heading, placeholder, highlighted guidance
      paragraph, <LITERAL> block and table (with its rows), each tagged with
      the section it belongs to. Read this before writing a spec.

  docx_template.py fill template.docx spec.json out.docx
      Applies a JSON spec (see references/spec-format.md) and then runs a
      finalize pass: strips <LITERAL> markers, deletes leftover highlighted
      guidance, rebuilds the table of contents and reports anything that
      still looks unfinished (placeholders, highlights, must-change values).

Everything not touched by the spec keeps its original XML, so headers,
footers, logos, page setup, fonts, numbering and table styles survive.
"""
import copy, json, re, sys
import docx
from lxml import etree
from docx.oxml.ns import qn

def etree_tostring(el):
    return etree.tostring(el, encoding="unicode")
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.text.paragraph import Paragraph
from docx.table import Table

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
LIT = re.compile(r"\s*<\s*LITERAL\s*>\s*", re.I)
PLACEHOLDER = re.compile(r"\[[^\[\]]{3,80}\]")

# ---------------------------------------------------------------- helpers

def ptext(p_el):
    return "".join(t.text or "" for t in p_el.iter(qn("w:t")))

def style_name(doc, p_el):
    ps = p_el.find(qn("w:pPr") + "/" + qn("w:pStyle"))
    if ps is None:
        return "Normal"
    sid = ps.get(qn("w:val"))
    try:
        return doc.styles.get_by_id(sid, 1).name  # 1 = paragraph
    except Exception:
        return sid

def heading_level(doc, p_el):
    m = re.match(r"(?i)heading\s*(\d)", style_name(doc, p_el) or "")
    return int(m.group(1)) if m else 0

def text_runs(p_el):
    return [r for r in p_el.iter(qn("w:r")) if r.find(qn("w:t")) is not None]

def is_highlighted_run(r):
    h = r.find(qn("w:rPr") + "/" + qn("w:highlight"))
    return h is not None and h.get(qn("w:val")) not in (None, "none", "white")

def is_guidance(p_el):
    """Every visible character of the paragraph is highlighted and it is not a LITERAL."""
    txt = ptext(p_el)
    if not txt.strip() or LIT.search(txt):
        return False
    runs = [r for r in text_runs(p_el)
            if re.search(r"\w", "".join(t.text or "" for t in r.iter(qn("w:t"))))]
    return bool(runs) and all(is_highlighted_run(r) for r in runs)

def has_highlight(el):
    return any(is_highlighted_run(r) for r in el.iter(qn("w:r")))

def strip_highlight(el):
    for h in list(el.iter(qn("w:highlight"))):
        h.getparent().remove(h)

def body_elements(doc):
    return [e for e in doc.element.body if e.tag in (qn("w:p"), qn("w:tbl"), qn("w:sdt"))]

def all_paragraphs(doc):
    """Paragraphs in body (incl. tables) plus headers/footers."""
    ps = list(doc.element.body.iter(qn("w:p")))
    for s in doc.sections:
        for part in (s.header, s.footer, s.first_page_header, s.first_page_footer):
            try:
                ps += list(part._element.iter(qn("w:p")))
            except Exception:
                pass
    return ps

def para_sub(p_el, pattern, repl, count=0):
    """Regex-replace across runs while keeping each run's formatting.
    Replacement text inherits the formatting of the run where the match starts."""
    ts = [t for t in p_el.iter(qn("w:t"))]
    if not ts:
        return 0
    full = "".join(t.text or "" for t in ts)
    matches = list(re.finditer(pattern, full))
    if count:
        matches = matches[:count]
    if not matches:
        return 0
    owner = []  # char index -> t index
    for i, t in enumerate(ts):
        owner += [i] * len(t.text or "")
    pieces = [list(t.text or "") for t in ts]
    offsets = []
    pos = 0
    for t in ts:
        offsets.append(pos)
        pos += len(t.text or "")
    for m in reversed(matches):
        s, e = m.start(), m.end()
        new = m.expand(repl) if isinstance(repl, str) else repl(m)
        if s == e:
            continue
        ti = owner[s]
        # delete chars s..e across runs
        for c in range(e - 1, s - 1, -1):
            j = owner[c]
            del pieces[j][c - offsets[j]]
        pieces[ti][s - offsets[ti]:s - offsets[ti]] = list(new)
    for t, pc in zip(ts, pieces):
        t.text = "".join(pc)
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return len(matches)

# ---------------------------------------------------------------- inline markup

INLINE = re.compile(r"(\*\*.+?\*\*|\*[^*]+?\*|\[[^\]]+\]\([^)]+\))")

def add_inline(doc, p_el, text, rpr_proto):
    """Append runs to p_el from lightweight markdown: **bold**, *italic*, [text](url)."""
    for chunk in INLINE.split(text):
        if not chunk:
            continue
        bold = italic = False
        url = None
        if chunk.startswith("**") and chunk.endswith("**") and len(chunk) > 4:
            chunk, bold = chunk[2:-2], True
        elif chunk.startswith("*") and chunk.endswith("*") and len(chunk) > 2:
            chunk, italic = chunk[1:-1], True
        else:
            m = re.fullmatch(r"\[([^\]]+)\]\(([^)]+)\)", chunk)
            if m:
                chunk, url = m.group(1), m.group(2)
        r = docx.oxml.OxmlElement("w:r")
        rpr = copy.deepcopy(rpr_proto) if rpr_proto is not None else docx.oxml.OxmlElement("w:rPr")
        strip_highlight(rpr)
        def put(tag, val="1"):
            for old in rpr.findall(qn(tag)):
                rpr.remove(old)
            el = docx.oxml.OxmlElement(tag); el.set(qn("w:val"), val); rpr.append(el)
        if bold: put("w:b"); put("w:bCs")
        if italic: put("w:i"); put("w:iCs")
        if url:
            put("w:u", "single")
            c = rpr.find(qn("w:color"))
            if c is None:
                c = docx.oxml.OxmlElement("w:color"); rpr.append(c)
            c.set(qn("w:val"), "1155CC")
        _order_rpr(rpr)
        r.append(rpr)
        t = docx.oxml.OxmlElement("w:t"); t.text = chunk
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
        r.append(t)
        if url:
            rid = doc.part.relate_to(url, RT.HYPERLINK, is_external=True)
            h = docx.oxml.OxmlElement("w:hyperlink"); h.set(qn("r:id"), rid); h.append(r)
            p_el.append(h)
        else:
            p_el.append(r)

RPR_ORDER = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike",
             "outline", "shadow", "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden",
             "color", "spacing", "w", "kern", "position", "sz", "szCs", "highlight", "u", "effect",
             "bdr", "shd", "fitText", "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout",
             "specVanish", "oMath"]

def _order_rpr(rpr):
    kids = list(rpr)
    def key(k):
        n = k.tag.split("}")[1]
        return RPR_ORDER.index(n) if n in RPR_ORDER else 99
    kids.sort(key=key)
    for k in kids:
        rpr.remove(k)
    for k in kids:
        rpr.append(k)

def first_rpr(p_el):
    for r in text_runs(p_el):
        rp = r.find(qn("w:rPr"))
        if rp is not None:
            return rp
    return None

def clone_para(doc, proto, text):
    """New paragraph with proto's paragraph properties and first-run formatting."""
    p = docx.oxml.OxmlElement("w:p")
    ppr = proto.find(qn("w:pPr"))
    if ppr is not None:
        ppr = copy.deepcopy(ppr)
        strip_highlight(ppr)
        p.append(ppr)
    add_inline(doc, p, text, first_rpr(proto))
    return p

def set_para_text(doc, p_el, text):
    rpr = first_rpr(p_el)
    rpr = copy.deepcopy(rpr) if rpr is not None else None
    for k in list(p_el):
        if k.tag != qn("w:pPr"):
            # keep bookmarks so TOC links survive
            if k.tag in (qn("w:bookmarkStart"), qn("w:bookmarkEnd")):
                continue
            p_el.remove(k)
    add_inline(doc, p_el, text, rpr)

# ---------------------------------------------------------------- document model

class Tpl:
    def __init__(self, path):
        self.doc = docx.Document(path)
        self.warn = []
        self.log = []
        self._protos = None
        self._table_sources = {}
        sec, counts = None, {}
        for e in body_elements(self.doc):
            if e.tag == qn("w:p") and heading_level(self.doc, e) and ptext(e).strip():
                sec = ptext(e).strip()
            elif e.tag == qn("w:tbl") and sec:
                n = counts.get(sec, 0); counts[sec] = n + 1
                self._table_sources[(sec, n)] = copy.deepcopy(e)

    # sections -------------------------------------------------------
    def headings(self):
        out = []
        for e in body_elements(self.doc):
            if e.tag == qn("w:p"):
                lvl = heading_level(self.doc, e)
                if lvl and ptext(e).strip():
                    out.append((e, lvl, ptext(e).strip()))
        return out

    def find_heading(self, name):
        norm = lambda s: re.sub(r"\W+", " ", s).strip().lower()
        hs = self.headings()
        for e, lvl, t in hs:
            if norm(t) == norm(name):
                return e, lvl
        for e, lvl, t in hs:
            if norm(name) in norm(t):
                return e, lvl
        raise KeyError(f"heading not found: {name!r}. Headings: {[t for _, _, t in hs]}")

    def section_range(self, name, include_subsections=False):
        """Elements after the heading up to the next heading (any level, or same/higher if include_subsections)."""
        h, lvl = self.find_heading(name)
        els = body_elements(self.doc)
        i = els.index(h)
        out = []
        for e in els[i + 1:]:
            if e.tag == qn("w:p"):
                l2 = heading_level(self.doc, e)
                if l2 and ptext(e).strip() and (not include_subsections or l2 <= lvl):
                    break
            out.append(e)
        return h, lvl, out

    # prototypes -----------------------------------------------------
    def protos(self):
        """Pick the paragraph to copy for each block type: the MOST COMMON format among
        body paragraphs (guidance text included: it is written in the style the author is
        meant to use), preferring an unhighlighted example of that format."""
        if self._protos:
            return self._protos
        import collections
        numfmt = self._numfmts()
        groups = collections.defaultdict(list)   # key -> [elements]
        pr = {}
        started = False
        def fmt_key(e):
            ps = e.find(qn("w:pPr") + "/" + qn("w:pStyle"))
            rp = first_rpr(e)
            sz = rp.find(qn("w:sz")).get(qn("w:val")) if rp is not None and rp.find(qn("w:sz")) is not None else None
            fnt = rp.find(qn("w:rFonts")) if rp is not None else None
            fnt = fnt.get(qn("w:ascii")) if fnt is not None else None
            return (ps.get(qn("w:val")) if ps is not None else None, sz, fnt)
        for e in self.doc.element.body.iter(qn("w:p")):
            lvl = heading_level(self.doc, e)
            if lvl == 1 and e.find(".//" + qn("w:numPr")) is not None:
                started = True
            if not started or e.getparent().tag != qn("w:body"):
                continue
            t = ptext(e).strip()
            if not t or LIT.search(t):
                continue
            if lvl:
                pr.setdefault(f"h{lvl}", e)
                continue
            num = e.find(qn("w:pPr") + "/" + qn("w:numPr"))
            if num is None:
                if len(t) > 25:
                    groups[("body",) + fmt_key(e)].append(e)
            else:
                nid = num.find(qn("w:numId")).get(qn("w:val"))
                il = int(num.find(qn("w:ilvl")).get(qn("w:val")))
                if numfmt.get((nid, il)) == "bullet":
                    groups[(f"bullet{il}",) + fmt_key(e)].append(e)
        for kind in ["body"] + [f"bullet{i}" for i in range(9)]:
            cands = [(len(v), k) for k, v in groups.items() if k[0] == kind]
            if not cands:
                continue
            best = max(cands)[1]
            els = groups[best]
            pr[kind] = next((e for e in els if not has_highlight(e)), els[0])
        if "body" not in pr:
            pr["body"] = next(iter(self.doc.element.body.iter(qn("w:p"))))
        self._protos = pr
        return pr

    def _numfmts(self):
        out = {}
        try:
            np = self.doc.part.numbering_part.element
        except Exception:
            return out
        absfmt = {}
        for a in np.findall(qn("w:abstractNum")):
            aid = a.get(qn("w:abstractNumId"))
            for l in a.findall(qn("w:lvl")):
                f = l.find(qn("w:numFmt"))
                absfmt[(aid, int(l.get(qn("w:ilvl"))))] = f.get(qn("w:val")) if f is not None else None
        for n in np.findall(qn("w:num")):
            nid = n.get(qn("w:numId"))
            aid = n.find(qn("w:abstractNumId")).get(qn("w:val"))
            for (a2, il), f in absfmt.items():
                if a2 == aid:
                    out[(nid, il)] = f
        return out

    def make_block(self, b):
        pr = self.protos()
        if isinstance(b, str):
            b = {"type": "p", "text": b}
        t = b.get("type", "p")
        if t == "p":
            return clone_para(self.doc, pr["body"], b["text"])
        if t == "bullet":
            lvl = int(b.get("level", 0))
            proto = pr.get(f"bullet{lvl}")
            if proto is None:
                proto = pr.get("bullet0")
            if proto is None:
                raise ValueError("template has no bullet list to copy")
            return clone_para(self.doc, proto, b["text"])
        if t == "heading":
            lvl = int(b.get("level", 2))
            proto = pr.get(f"h{lvl}")
            if proto is None:
                raise ValueError(f"template has no Heading {lvl} to copy")
            return clone_para(self.doc, proto, b["text"])
        if t == "label":  # bold lead-in line such as "Supuestos:"
            return clone_para(self.doc, pr["body"], f"**{b['text']}**")
        if t == "table":
            return self.clone_table(b)
        raise ValueError(f"unknown block type {t}")

    def clone_table(self, b):
        """New table copying the design of an existing one: {"like": <section>, "nth": 0,
        "header": [...], "rows": [[...]], "footer": [...]?}. Column count follows the source
        table; give exactly that many values per row (use "" for blanks)."""
        norm = lambda x: re.sub(r"\W+", " ", x).strip().lower()
        src = next((v for (k, n), v in self._table_sources.items()
                    if n == b.get("nth", 0) and norm(b["like"]) in norm(k)), None)
        if src is None:
            raise ValueError(f"table block: no table under {b['like']!r}")
        tbl = copy.deepcopy(src)
        rows = tbl.findall(qn("w:tr"))
        head, proto = rows[0], copy.deepcopy(rows[1] if len(rows) > 1 else rows[0])
        foot_proto = copy.deepcopy(rows[-1]) if len(rows) > 2 else copy.deepcopy(proto)
        for r in rows[1:]:
            tbl.remove(r)
        if b.get("header"):
            self._fill_row(head, b["header"])
        self._mark_header(head)
        for vals in b.get("rows", []):
            nr = copy.deepcopy(proto); self._fill_row(nr, vals); tbl.append(nr)
        if b.get("footer"):
            nr = copy.deepcopy(foot_proto); self._fill_row(nr, b["footer"]); tbl.append(nr)
        return tbl

    # operations -----------------------------------------------------
    def op_replace(self, mapping):
        for old, new in mapping.items():
            n = sum(para_sub(p, re.escape(old), new.replace("\\", "\\\\")) for p in all_paragraphs(self.doc))
            if not n:
                self.warn.append(f"replace: {old!r} not found")
            self.log.append(f"replace {old!r} x{n}")

    def op_fixes(self, fixes):
        for f in fixes:
            n = sum(para_sub(p, f["find"], f["replace"]) for p in all_paragraphs(self.doc))
            self.log.append(f"fix {f['find']!r} x{n}")

    def op_set_paragraphs(self, items):
        for it in items:
            hits = [p for p in all_paragraphs(self.doc) if re.search(it["match"], ptext(p))]
            if not hits:
                self.warn.append(f"set_paragraphs: no paragraph matches {it['match']!r}")
                continue
            for p in hits[: it.get("count", 1)]:
                set_para_text(self.doc, p, it["text"])
                if not it.get("keep_highlight"):
                    strip_highlight(p)

    def op_delete_paragraphs(self, items):
        for it in items:
            m = it if isinstance(it, dict) else {"match": it}
            hits = [p for p in self.doc.element.body.iter(qn("w:p")) if re.search(m["match"], ptext(p))]
            occ = m.get("occurrence")
            if occ:
                hits = hits[occ - 1:occ]
            for p in hits:
                p.getparent().remove(p)
            self.log.append(f"delete_paragraphs {m['match']!r} x{len(hits)}")

    def op_promote(self, items):
        for it in items:
            hits = [p for p in self.doc.element.body if p.tag == qn("w:p") and re.search(it["match"], ptext(p))]
            if not hits:
                self.warn.append(f"promote: nothing matches {it['match']!r}")
                continue
            like, _ = self.find_heading(it["like"])
            p = hits[0]
            ppr_new = copy.deepcopy(like.find(qn("w:pPr")))
            old = p.find(qn("w:pPr"))
            if old is not None:
                p.remove(old)
            p.insert(0, ppr_new)
            rpr = first_rpr(like)
            for k in list(p):
                if k.tag not in (qn("w:pPr"), qn("w:bookmarkStart"), qn("w:bookmarkEnd")):
                    p.remove(k)
            add_inline(self.doc, p, it["text"], copy.deepcopy(rpr) if rpr is not None else None)

    def op_rebuild_body(self, spec):
        """Replace everything from the first numbered Heading 1 (or `from` heading) to the end
        with new blocks, keeping cover, TOC, header/footer, styles and page setup."""
        protos = self.protos()  # capture prototypes before deleting
        if spec.get("from"):
            start, _ = self.find_heading(spec["from"])
        else:
            start = next(e for e, lvl, t in self.headings()
                         if lvl == 1 and e.find(qn("w:pPr") + "/" + qn("w:numPr")) is not None)
        els = body_elements(self.doc)
        i = els.index(start)
        anchor = els[i - 1]
        for e in els[i:]:
            e.getparent().remove(e)
        cur = anchor
        for b in spec.get("content", []):
            new = self.make_block(b)
            cur.addnext(new); cur = new
        self.log.append(f"body rebuilt with {len(spec.get('content', []))} blocks")

    def op_delete_sections(self, names):
        for name in names:
            h, lvl, rng = self.section_range(name, include_subsections=True)
            for e in [h] + rng:
                e.getparent().remove(e)
            self.log.append(f"deleted section {name!r}")

    def op_sections(self, sections):
        for name, spec in sections.items():
            if isinstance(spec, list):
                spec = {"content": spec}
            mode = spec.get("mode", "guidance")
            h, lvl, rng = self.section_range(name)
            paras = [e for e in rng if e.tag == qn("w:p")]
            if mode == "replace_all":
                victims = [p for p in paras]
            elif mode == "append":
                victims = []
            else:  # guidance
                victims = [p for p in paras if is_guidance(p)]
            anchor_after = h
            if victims:
                els = list(h.getparent())
                first = victims[0]
                idx = els.index(first)
                anchor_after = els[idx - 1]
            elif mode == "append" and rng:
                anchor_after = rng[-1]
            for v in victims:
                v.getparent().remove(v)
            cur = anchor_after
            for b in spec.get("content", []):
                if isinstance(b, dict) and b.get("type") == "keep":
                    # move an existing paragraph (e.g. a <LITERAL>) to this position, untouched
                    hits = [e for e in self.doc.element.body.iter(qn("w:p")) if re.search(b["match"], ptext(e))]
                    if not hits:
                        self.warn.append(f"keep: nothing matches {b['match']!r}")
                        continue
                    new = hits[0]
                    new.getparent().remove(new)
                else:
                    new = self.make_block(b)
                cur.addnext(new)
                cur = new
            self.log.append(f"section {name!r}: removed {len(victims)}, added {len(spec.get('content', []))}")

    def tables_in(self, name):
        h, lvl, rng = self.section_range(name, include_subsections=False)
        return [e for e in rng if e.tag == qn("w:tbl")]

    def op_tables(self, items):
        for it in items:
            tbls = self.tables_in(it["section"])
            if not tbls:
                self.warn.append(f"tables: no table under {it['section']!r}")
                continue
            tbl = tbls[it.get("nth", 0)]
            rows = tbl.findall(qn("w:tr"))
            nh = it.get("header_rows", 1)
            header = rows[:nh]
            has_footer = "footer" in it
            footer = rows[-1] if has_footer else None
            body = rows[nh:-1] if has_footer else rows[nh:]
            if it.get("header"):
                self._fill_row(header[-1], it["header"])
            for hr in header:
                self._mark_header(hr)
            proto = copy.deepcopy(body[0] if body else header[-1])
            for r in body:
                tbl.remove(r)
            insert_before = footer
            for vals in it.get("rows", []):
                nr = copy.deepcopy(proto)
                self._fill_row(nr, vals)
                if insert_before is not None:
                    insert_before.addprevious(nr)
                else:
                    tbl.append(nr)
            if it.get("widths_pct"):
                self._set_widths(tbl, it["widths_pct"])
            if has_footer:
                if it["footer"] is None:
                    tbl.remove(footer)
                else:
                    self._fill_row(footer, it["footer"])
            self.log.append(f"table under {it['section']!r}: {len(it.get('rows', []))} rows")

    def _fill_row(self, tr, vals):
        cells = tr.findall(qn("w:tc"))
        if len(vals) != len(cells):
            self.warn.append(f"row has {len(cells)} cells but {len(vals)} values: {vals}")
        for tc, v in zip(cells, vals):
            if v is None:  # keep cell as is
                continue
            if isinstance(v, dict):  # {"text": ..., "fill": "FCE5CD" | null}
                if "fill" in v:
                    self._set_fill(tc, v["fill"])
                v = v.get("text", "")
            ps = tc.findall(qn("w:p"))
            proto = ps[0]
            items = v if isinstance(v, list) else [v]
            for p in ps:
                tc.remove(p)
            for item in items:
                tc.append(clone_para(self.doc, proto, str(item)))
            strip_highlight(tc)

    def _mark_header(self, tr):
        """Repeat the header row on every page and keep it with the first data row."""
        trpr = tr.find(qn("w:trPr"))
        if trpr is None:
            trpr = docx.oxml.OxmlElement("w:trPr")
            tc = tr.find(qn("w:tc"))
            tc.addprevious(trpr)
        if trpr.find(qn("w:tblHeader")) is None:
            h = docx.oxml.OxmlElement("w:tblHeader"); trpr.append(h)
        for p in tr.iter(qn("w:p")):
            ppr = p.find(qn("w:pPr"))
            if ppr is None:
                ppr = docx.oxml.OxmlElement("w:pPr"); p.insert(0, ppr)
            if ppr.find(qn("w:keepNext")) is None:
                kn = docx.oxml.OxmlElement("w:keepNext")
                ps = ppr.find(qn("w:pStyle"))
                (ps.addnext(kn) if ps is not None else ppr.insert(0, kn))

    def _set_widths(self, tbl, pct):
        """Redistribute column widths (percentages of the current total width)."""
        grid = tbl.find(qn("w:tblGrid"))
        cols = grid.findall(qn("w:gridCol"))
        if len(pct) != len(cols):
            self.warn.append(f"widths_pct has {len(pct)} values but table has {len(cols)} columns")
            return
        total = sum(int(c.get(qn("w:w"))) for c in cols)
        ws = [int(total * p / sum(pct)) for p in pct]
        for c, w in zip(cols, ws):
            c.set(qn("w:w"), str(w))
        for tr in tbl.findall(qn("w:tr")):
            i = 0
            for tc in tr.findall(qn("w:tc")):
                tcpr = tc.find(qn("w:tcPr"))
                span = tcpr.find(qn("w:gridSpan")) if tcpr is not None else None
                n = int(span.get(qn("w:val"))) if span is not None else 1
                tcw = tcpr.find(qn("w:tcW")) if tcpr is not None else None
                if tcw is not None:
                    tcw.set(qn("w:w"), str(sum(ws[i:i + n]))); tcw.set(qn("w:type"), "dxa")
                i += n

    def _set_fill(self, tc, color):
        tcpr = tc.find(qn("w:tcPr"))
        if tcpr is None:
            tcpr = docx.oxml.OxmlElement("w:tcPr"); tc.insert(0, tcpr)
        for old in tcpr.findall(qn("w:shd")):
            tcpr.remove(old)
        if color:
            shd = docx.oxml.OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), color)
            # schema order: shd comes after borders, before noWrap/tcMar/vAlign...
            after = [qn(t) for t in ("w:noWrap", "w:tcMar", "w:textDirection", "w:tcFitText", "w:vAlign", "w:hideMark")]
            nxt = next((k for k in tcpr if k.tag in after), None)
            if nxt is not None:
                nxt.addprevious(shd)
            else:
                tcpr.append(shd)

    def op_remove_images(self, names):
        for name in names:
            h, lvl, rng = self.section_range(name)
            n = 0
            for e in rng:
                for d in list(e.iter(qn("w:drawing"))):
                    r = d.getparent()
                    r.getparent().remove(r); n += 1
            self.log.append(f"removed {n} image(s) under {name!r}")

    def op_replace_image(self, items):
        for it in items:
            h, lvl, rng = self.section_range(it["section"])
            blips = [b for e in rng for b in e.iter("{http://schemas.openxmlformats.org/drawingml/2006/main}blip")]
            if not blips:
                self.warn.append(f"replace_image: no image under {it['section']!r}")
                continue
            rid = blips[0].get(qn("r:embed"))
            part = self.doc.part.related_parts[rid]
            data = open(it["path"], "rb").read()
            part._blob = data
            try:
                from PIL import Image
                import io
                w, hgt = Image.open(io.BytesIO(data)).size
                ext = blips[0].getparent().getparent().getparent().getparent().getparent()
                for e in [x for x in ext.iter() if x.tag.endswith("}extent") or x.tag.endswith("}ext")]:
                    cx = int(e.get("cx")); e.set("cy", str(int(cx * hgt / w)))
            except Exception:
                pass

    # finalize -------------------------------------------------------
    def finalize(self, must_change=()):
        # LITERAL: keep text, drop markers and highlight
        for p in all_paragraphs(self.doc):
            if LIT.search(ptext(p)):
                para_sub(p, r"\s*<\s*LITERAL\s*>\s*", " ")
                para_sub(p, r"^\s+|\s+$", "")
                para_sub(p, r"\s{2,}", " ")
                strip_highlight(p)
        # leftover guidance paragraphs outside tables
        removed = []
        for p in list(self.doc.element.body.iter(qn("w:p"))):
            if p.getparent().tag == qn("w:body") and is_guidance(p):
                removed.append(ptext(p).strip()[:90])
                p.getparent().remove(p)
        if removed:
            self.warn.append("removed leftover guidance (check you covered it): " + " | ".join(removed))
        # empty list items left behind
        for p in list(self.doc.element.body.iter(qn("w:p"))):
            if p.find(qn("w:pPr") + "/" + qn("w:numPr")) is not None and not ptext(p).strip() \
                    and p.find(".//" + qn("w:drawing")) is None and heading_level(self.doc, p) == 0:
                p.getparent().remove(p)
        # remaining highlight anywhere
        for p in all_paragraphs(self.doc):
            if has_highlight(p) and ptext(p).strip():
                self.warn.append(f"still highlighted: {ptext(p).strip()[:90]!r}")
        for p in all_paragraphs(self.doc):
            for m in PLACEHOLDER.finditer(ptext(p)):
                self.warn.append(f"placeholder left: {m.group(0)!r}")
        for pat in must_change:
            for p in all_paragraphs(self.doc):
                if re.search(pat, ptext(p)):
                    self.warn.append(f"example value still present ({pat}): {ptext(p).strip()[:90]!r}")
        self.rebuild_toc()

    def rebuild_toc(self):
        sdt = next((e for e in self.doc.element.body if e.tag == qn("w:sdt")
                    and e.find(".//" + qn("w:docPartGallery")) is not None
                    and "Contents" in e.find(".//" + qn("w:docPartGallery")).get(qn("w:val"))), None)
        if sdt is None:
            return
        content = sdt.find(qn("w:sdtContent"))
        entries = [p for p in content.findall(qn("w:p"))]
        if len(entries) < 2:
            return
        # prototypes for level-1 and level-2 entries
        def lvl_of(p):
            ind = p.find(qn("w:pPr") + "/" + qn("w:ind"))
            return 2 if ind is not None and int(ind.get(qn("w:left"), "0") or 0) > 0 else 1
        proto = {1: None, 2: None}
        for p in entries[1:]:
            proto.setdefault(lvl_of(p), p)
            if proto[lvl_of(p)] is None:
                proto[lvl_of(p)] = p
        proto[1] = proto[1] if proto[1] is not None else entries[1]
        proto[2] = proto[2] if proto[2] is not None else proto[1]
        first, last = entries[0], entries[-1]
        # heading list with computed numbers
        n1 = n2 = 0
        items = []
        bm_id = 9000
        for h, lvl, t in self.headings():
            if lvl > 2:
                continue
            numbered = h.find(qn("w:pPr") + "/" + qn("w:numPr")) is not None
            if numbered and lvl == 1:
                n1 += 1; n2 = 0; label = f"{n1}. {t}"
            elif numbered and lvl == 2:
                n2 += 1; label = f"{n1}.{n2}. {t}"
            else:
                label = t
            if t.lower() in ("contenido", "contents", "índice", "indice", "table of contents"):
                continue
            bs = h.find(qn("w:bookmarkStart"))
            if bs is None:
                bm_id += 1
                name = f"_toc{bm_id}"
                bs = docx.oxml.OxmlElement("w:bookmarkStart"); bs.set(qn("w:id"), str(bm_id)); bs.set(qn("w:name"), name)
                be = docx.oxml.OxmlElement("w:bookmarkEnd"); be.set(qn("w:id"), str(bm_id))
                ppr = h.find(qn("w:pPr"))
                if ppr is not None:
                    ppr.addnext(bs)
                else:
                    h.insert(0, bs)
                h.append(be)
            items.append((lvl, label, bs.get(qn("w:name"))))
        # rebuild: keep field begin in first entry, field end in last
        begin_runs = [r for r in first if r.tag == qn("w:r") and r.find(qn("w:fldChar")) is not None]
        end_runs = [r for r in last.iter(qn("w:r")) if r.find(qn("w:fldChar")) is not None
                    and r.find(qn("w:fldChar")).get(qn("w:fldCharType")) == "end"]
        for p in entries:
            content.remove(p)
        for i, (lvl, label, anchor) in enumerate(items):
            pr = proto[lvl]
            p = docx.oxml.OxmlElement("w:p")
            ppr = pr.find(qn("w:pPr"))
            if ppr is not None:
                ppr = copy.deepcopy(ppr)
                tabs = ppr.find(qn("w:tabs"))
                if tabs is not None:
                    ppr.remove(tabs)
                p.append(ppr)
            if i == 0:
                for r in begin_runs:
                    p.append(copy.deepcopy(r))
            hl = docx.oxml.OxmlElement("w:hyperlink"); hl.set(qn("w:anchor"), anchor)
            rpr_src = None
            for r in pr.iter(qn("w:r")):
                if r.find(qn("w:t")) is not None and (r.find(qn("w:t")).text or "").strip():
                    rpr_src = r.find(qn("w:rPr")); break
            r = docx.oxml.OxmlElement("w:r")
            if rpr_src is not None:
                r.append(copy.deepcopy(rpr_src))
            t = docx.oxml.OxmlElement("w:t"); t.text = label
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            r.append(t); hl.append(r); p.append(hl)
            if i == len(items) - 1:
                for er in end_runs:
                    p.append(copy.deepcopy(er))
            content.append(p)
        self.log.append(f"TOC rebuilt with {len(items)} entries")

    def save(self, path):
        # drop images and hyperlinks no longer referenced (removed sections/examples)
        xml = etree_tostring(self.doc.element)
        for rid, rel in list(self.doc.part.rels.items()):
            if rel.reltype in (RT.IMAGE, RT.HYPERLINK) and f'"{rid}"' not in xml:
                del self.doc.part.rels[rid]
        self.doc.save(path)

# ---------------------------------------------------------------- commands

def cmd_inspect(path):
    t = Tpl(path)
    doc = t.doc
    section = "(cover)"
    ti = 0
    print(f"# {path}")
    s0 = doc.sections[0]
    print(f"page: {s0.page_width.cm:.1f}x{s0.page_height.cm:.1f} cm, margins L{s0.left_margin.cm:.1f} R{s0.right_margin.cm:.1f} T{s0.top_margin.cm:.1f} B{s0.bottom_margin.cm:.1f} cm")
    hdr = " ".join(ptext(p) for p in s0.header._element.iter(qn("w:p"))).strip()
    print(f"header: text={hdr!r} images={len(list(s0.header._element.iter(qn('w:drawing'))))}")
    for e in body_elements(doc):
        if e.tag == qn("w:sdt"):
            print(f"  [TOC] {len(e.findall('.//' + qn('w:p')))} entries (rebuilt automatically on fill)")
            continue
        if e.tag == qn("w:tbl"):
            rows = e.findall(qn("w:tr"))
            print(f"  [TABLE #{ti} in {section!r}] {len(rows)} rows")
            for ri, tr in enumerate(rows):
                cells = [ptext_cell(tc) for tc in tr.findall(qn("w:tc"))]
                if any(c.strip() for c in cells) or ri < 2:
                    flag = " HL" if has_highlight(tr) else ""
                    print(f"      r{ri}{flag}: " + " | ".join(c[:40] for c in cells))
            ti += 1
            continue
        txt = ptext(e).strip()
        lvl = heading_level(doc, e)
        if lvl and txt:
            section = txt
            num = " (numbered)" if e.find(qn("w:pPr") + "/" + qn("w:numPr")) is not None else ""
            print(f"H{lvl}{num}: {txt}")
            continue
        if not txt:
            if e.find(".//" + qn("w:drawing")) is not None:
                print(f"  [IMAGE] in {section!r}")
            continue
        tags = []
        if LIT.search(txt): tags.append("LITERAL")
        elif is_guidance(e): tags.append("GUIDANCE")
        elif has_highlight(e): tags.append("PART-HL")
        if PLACEHOLDER.search(txt): tags.append("PLACEHOLDER")
        if e.find(qn("w:pPr") + "/" + qn("w:numPr")) is not None:
            il = e.find(qn("w:pPr") + "/" + qn("w:numPr") + "/" + qn("w:ilvl"))
            tags.append(f"list{il.get(qn('w:val')) if il is not None else ''}")
        print(f"  [{','.join(tags) or 'text'}] {txt[:110]}")

def ptext_cell(tc):
    return " / ".join(ptext(p) for p in tc.findall(qn("w:p")) if ptext(p).strip())

def cmd_fill(src, spec_path, out):
    spec = json.load(open(spec_path, encoding="utf-8"))
    must = list(spec.get("must_change", []))
    fixes = list(spec.get("fixes", []))
    promote = list(spec.get("promote", []))
    deletes = list(spec.get("delete_paragraphs", []))
    for prof in spec.get("profiles", []):
        pj = json.load(open(prof, encoding="utf-8"))
        fixes = pj.get("fixes", []) + fixes
        promote = pj.get("promote", []) + promote
        deletes = pj.get("delete_paragraphs", []) + deletes
        must += pj.get("must_change", [])
    t = Tpl(src)
    # structure first, then text, so matches see the original wording
    if promote: t.op_promote(promote)
    if deletes: t.op_delete_paragraphs(deletes)
    if spec.get("rebuild_body"): t.op_rebuild_body(spec["rebuild_body"])
    if spec.get("delete_sections"): t.op_delete_sections(spec["delete_sections"])
    if spec.get("remove_images"): t.op_remove_images(spec["remove_images"])
    if spec.get("replace_image"): t.op_replace_image(spec["replace_image"])
    if spec.get("tables"): t.op_tables(spec["tables"])
    if spec.get("sections"): t.op_sections(spec["sections"])
    if spec.get("set_paragraphs"): t.op_set_paragraphs(spec["set_paragraphs"])
    if spec.get("replace"): t.op_replace(spec["replace"])
    if fixes: t.op_fixes(fixes)
    t.finalize(must)
    t.save(out)
    print("\n".join("  " + l for l in t.log))
    if t.warn:
        print("\nWARNINGS (resolve these, then re-run):")
        for w in t.warn:
            print("  - " + w)
    else:
        print("\nOK: no leftover placeholders, highlights or example values.")

if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "inspect":
        cmd_inspect(sys.argv[2])
    elif len(sys.argv) == 5 and sys.argv[1] == "fill":
        cmd_fill(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        print(__doc__); sys.exit(1)
