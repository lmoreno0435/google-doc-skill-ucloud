#!/usr/bin/env python3
"""Turn a Google Drive download_file_content result into a real file.

Large downloads are saved by the tool runner as a JSON file (path given in the
tool result). This decodes it without the base64 ever passing through the chat.

usage: extract_export.py <tool_result.json> <out_file>
Prints the document title so you can reuse it.
"""
import base64, json, sys

def find(obj):
    if isinstance(obj, dict):
        if "content" in obj and isinstance(obj["content"], str) and len(obj["content"]) > 100:
            return obj
        for v in obj.values():
            r = find(v)
            if r: return r
    if isinstance(obj, list):
        for v in obj:
            r = find(v)
            if r: return r
    if isinstance(obj, str):
        try:
            return find(json.loads(obj))
        except Exception:
            return None
    return None

src, out = sys.argv[1], sys.argv[2]
d = find(json.load(open(src)))
if not d:
    sys.exit("no base64 'content' field found")
open(out, "wb").write(base64.b64decode(d["content"]))
print(f"title: {d.get('title')}\nmime: {d.get('mimeType')}\nwrote: {out}")
