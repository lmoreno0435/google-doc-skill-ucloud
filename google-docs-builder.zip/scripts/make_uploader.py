#!/usr/bin/env python3
"""Wrap a finished .docx in a one-click "create in Google Drive" page.

The page calls the viewer's own Google Drive connector (create_file), which
converts the .docx into a native Google Doc. It also offers the .docx as a
download fallback. Publish the output with the Artifact tool using:
  capabilities = {"mcp": {"servers": [{"server": "Google Drive", "tools": ["create_file"]}]},
                  "downloads": true}

usage: make_uploader.py doc.docx out.html --title "Doc title" [--parent FOLDER_ID]
       [--summary "one line shown on the page"] [--lang es|en]
"""
import argparse, base64, html, json, os

T = {
 "es": dict(h="Listo para Google Drive", btn="Crear en Google Drive", busy="Creando documento…",
            ok="Documento creado", open="Abrir en Google Docs", dl="Descargar .docx",
            again="Reintentar", size="Tamaño", dest="Destino", root="Mi unidad",
            nomcp="Esta vista no puede usar tus conectores. Descarga el .docx y ábrelo con Google Docs.",
            reauth="Tu conexión con Google Drive expiró. Reconéctala en Configuración → Conectores y vuelve a intentarlo.",
            notconn="Google Drive no está conectado. Agrégalo en Configuración → Conectores.",
            denied="No se concedió acceso a Google Drive para esta página.",
            policy="La política de tu organización bloquea esta acción.",
            ambiguous="No hubo respuesta clara de Drive. Revisa tu Drive antes de reintentar para no duplicar el documento.",
            toolerr="Drive rechazó el archivo:", other="Algo falló:"),
 "en": dict(h="Ready for Google Drive", btn="Create in Google Drive", busy="Creating document…",
            ok="Document created", open="Open in Google Docs", dl="Download .docx",
            again="Try again", size="Size", dest="Destination", root="My Drive",
            nomcp="This view can't use your connectors. Download the .docx and open it with Google Docs.",
            reauth="Your Google Drive connection expired. Reconnect it in Settings → Connectors and try again.",
            notconn="Google Drive isn't connected. Add it in Settings → Connectors.",
            denied="Google Drive access wasn't granted for this page.",
            policy="Your organization's policy blocks this action.",
            ambiguous="Drive didn't answer clearly. Check your Drive before retrying so you don't create a duplicate.",
            toolerr="Drive rejected the file:", other="Something went wrong:"),
}

PAGE = r"""<!doctype html><html lang="__LANG__"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>__TITLE__</title>
<style>
:root{box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);
--bg:#f6f7f9;--card:#fff;--fg:#1f2328;--mut:#5f6670;--line:#e3e6ea;--acc:#1a73e8;--ok:#188038;--err:#c5221f}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#15171a;--card:#1e2126;--fg:#e8eaed;--mut:#9aa0a6;--line:#30343a;--acc:#8ab4f8;--ok:#81c995;--err:#f28b82}}
:root[data-theme="dark"]{--bg:#15171a;--card:#1e2126;--fg:#e8eaed;--mut:#9aa0a6;--line:#30343a;--acc:#8ab4f8;--ok:#81c995;--err:#f28b82}
html{scroll-padding-top:env(safe-area-inset-top,0px)}*,*:before,*:after{box-sizing:inherit}
body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 "Google Sans",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
main{max-width:560px;margin:0 auto;padding:32px 16px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:24px}
.eyebrow{color:var(--mut);font-size:13px;letter-spacing:.02em;text-transform:uppercase;margin:0 0 6px}
h1{font-size:20px;margin:0 0 6px;overflow-wrap:anywhere}p{margin:0 0 14px;color:var(--mut)}
dl{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;margin:0 0 20px;font-size:14px}dt{color:var(--mut)}dd{margin:0;overflow-wrap:anywhere}
.row{display:flex;flex-wrap:wrap;gap:10px}
button,a.btn{appearance:none;border:1px solid var(--line);background:transparent;color:var(--fg);font:inherit;padding:10px 16px;border-radius:999px;cursor:pointer;text-decoration:none}
.primary{background:var(--acc)!important;border-color:var(--acc)!important;color:#fff!important}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]) .primary{color:#0b1b33!important}}
button:disabled{opacity:.6;cursor:progress}
#msg{margin-top:16px;font-size:14px;min-height:1.5em}.ok{color:var(--ok)}.err{color:var(--err)}
</style></head><body><main><div class="card">
<p class="eyebrow">__H__</p><h1 id="t"></h1><p id="s"></p>
<dl><dt>__SIZE__</dt><dd id="sz"></dd><dt>__DEST__</dt><dd id="dest"></dd></dl>
<div class="row"><button id="go" class="primary" disabled>__BTN__</button><button id="dl">__DL__</button></div>
<div id="msg" role="status"></div></div></main>
<script>
const CFG = __CFG__;
const L = __L__;
const B64 = "__B64__";
const $ = id => document.getElementById(id);
$("t").textContent = CFG.title; $("s").textContent = CFG.summary || "";
if (!CFG.summary) $("s").remove();
$("sz").textContent = Math.round(B64.length * 3 / 4 / 1024) + " KB";
$("dest").textContent = CFG.parentName || (CFG.parentId ? CFG.parentId : L.root);
const msg = (t, cls, link) => { const m = $("msg"); m.className = cls || ""; m.textContent = t;
  if (link) { m.append(" "); const a = document.createElement("a"); a.href = link; a.target = "_blank"; a.rel = "noopener"; a.className = "btn primary"; a.textContent = L.open; m.append(document.createElement("br"), a); } };
let mcp = null, downloads = null, done = false;
(async () => {
  try { mcp = await window.claude?.use?.("mcp"); } catch (e) { mcp = null; }
  if (mcp) $("go").disabled = false; else { $("go").remove(); msg(L.nomcp, ""); }
})();
(async () => { try { downloads = await window.claude?.use?.("downloads"); } catch (e) {} })();
function bytes() { const bin = atob(B64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
$("dl").onclick = async () => {
  const name = CFG.title.replace(/[\\/:*?"<>|]+/g, " ").trim() + ".docx";
  const blob = new Blob([bytes()], {type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
  try { if (downloads) { await downloads.save({filename: name, data: blob}); return; } } catch (e) { if (e && e.code === "cancelled") return; }
  msg(L.nomcp, "err");
};
$("go").onclick = async () => {
  if (done || !mcp) return;
  const go = $("go"); go.disabled = true; go.textContent = L.busy; msg("");
  const input = { title: CFG.title, base64Content: B64,
    contentMimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" };
  if (CFG.parentId) input.parentId = CFG.parentId;
  try {
    const r = await mcp.callTool("Google Drive", "create_file", input);
    let p = r.payload; if (typeof p === "string") { try { p = JSON.parse(p); } catch (e) {} }
    const url = p && (p.viewUrl || (p.id ? "https://docs.google.com/document/d/" + p.id + "/edit" : null));
    done = true; go.remove(); msg(L.ok + (p && p.title ? ": " + p.title : ""), "ok", url);
  } catch (e) {
    const c = e && e.code; go.disabled = false; go.textContent = L.again;
    const map = { needs_reauth: L.reauth, server_not_connected: L.notconn, not_in_manifest: L.denied,
      consent_required: L.denied, blocked_by_policy: L.policy, approval_required: L.policy,
      not_granted: L.nomcp, capability_disabled: L.nomcp, capability_removed: L.nomcp,
      server_unavailable: L.ambiguous, cancelled: L.ambiguous };
    if (c === "tool_error") msg(L.toolerr + " " + (e.message || ""), "err");
    else if (c === "upstream_error" && !e.retryable) msg(L.ambiguous, "err");
    else msg(map[c] || (L.other + " " + (e && e.message || c || "")), "err");
  }
};
</script></body></html>"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("docx"); ap.add_argument("out")
    ap.add_argument("--title", required=True); ap.add_argument("--parent")
    ap.add_argument("--parent-name"); ap.add_argument("--summary", default="")
    ap.add_argument("--lang", default="es", choices=["es", "en"])
    a = ap.parse_args()
    b64 = base64.b64encode(open(a.docx, "rb").read()).decode()
    cfg = {"title": a.title, "summary": a.summary, "parentId": a.parent, "parentName": a.parent_name}
    L = T[a.lang]
    page = (PAGE.replace("__LANG__", a.lang).replace("__TITLE__", html.escape(a.title))
            .replace("__H__", L["h"]).replace("__SIZE__", L["size"]).replace("__DEST__", L["dest"])
            .replace("__BTN__", L["btn"]).replace("__DL__", L["dl"])
            .replace("__CFG__", json.dumps(cfg).replace("</", "<\\/"))
            .replace("__L__", json.dumps(L, ensure_ascii=False))
            .replace("__B64__", b64))
    open(a.out, "w", encoding="utf-8").write(page)
    print(f"wrote {a.out} ({os.path.getsize(a.out):,} B, docx {len(b64)*3//4:,} B)")

if __name__ == "__main__":
    main()
