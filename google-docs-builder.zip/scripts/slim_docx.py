#!/usr/bin/env python3
"""Shrink a .docx before uploading it to Google Drive.

Google Docs exports embed full TTF fonts (often 90%+ of the file). Google Docs
already has those fonts, so we drop the embedded copies and their references.
Optionally downscale large PNG/JPEG images.

usage: slim_docx.py in.docx out.docx [--max-image-px 1600]
"""
import re, sys, zipfile, io, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("dst")
    ap.add_argument("--max-image-px", type=int, default=1600)
    a = ap.parse_args()
    zin = zipfile.ZipFile(a.src)
    zout = zipfile.ZipFile(a.dst, "w", zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        name = item.filename
        data = zin.read(name)
        if name.startswith("word/fonts/") or name == "word/_rels/fontTable.xml.rels":
            continue
        if name == "word/fontTable.xml":
            data = re.sub(rb"<w:embed(Regular|Bold|Italic|BoldItalic)\b[^>]*/>", b"", data)
        if name == "[Content_Types].xml":
            data = re.sub(rb'<Default Extension="(ttf|odttf)"[^>]*/>', b"", data)
            data = re.sub(rb'<Override PartName="/word/fonts/[^"]*"[^>]*/>', b"", data)
        if name.startswith("word/media/") and name.lower().endswith((".png", ".jpg", ".jpeg")):
            try:
                from PIL import Image
                im = Image.open(io.BytesIO(data))
                if max(im.size) > a.max_image_px:
                    im.thumbnail((a.max_image_px, a.max_image_px))
                    buf = io.BytesIO()
                    im.save(buf, format="PNG" if name.lower().endswith(".png") else "JPEG", optimize=True)
                    if buf.tell() < len(data):
                        data = buf.getvalue()
            except Exception:
                pass
        zout.writestr(item, data)
    zout.close()
    import os
    print(f"{a.src}: {os.path.getsize(a.src):,} B -> {a.dst}: {os.path.getsize(a.dst):,} B")

if __name__ == "__main__":
    main()
